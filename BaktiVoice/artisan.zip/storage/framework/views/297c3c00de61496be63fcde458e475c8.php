<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BaktiVoice - Dashboard Admin</title>

    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>

    :root { --primary: #96ace0;
            --primary-hover: #7b94d1;
            --background: #eaf1fb;
            --card-bg: #ffffff;
            --border: rgba(186, 210, 240, 0.5);
            --text-main: #2c4a8e;
            --text-muted: #64748b;
            --font-family: 'Inter', sans-serif;
            --sidebar-width: 250px;
            --topbar-height: 70px;
            --radius: 12px;
            --shadow: 0 4px 15px rgba(123, 159, 232, 0.08);

            --gradient-pastel: linear-gradient(135deg, #7b9fe8 0%, #9bc3f8 50%, #b8d7ff 100%);
            --gradient-button: linear-gradient(135deg, #628cdb 0%, #4772c7 100%);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--font-family);
        }

        body {
            background-color: var(--background) !important;
            color: var(--text-main);
            display: flex;
            min-height: 100vh;
        }

        /* --- SIDEBAR  --- */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--gradient-pastel);
            border-right: 1px solid rgba(255, 255, 255, 0.4);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 24px 16px;
            overflow-y: auto;
            box-shadow: 4px 0 20px rgba(123, 159, 232, 0.15);
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 12px 24px 12px;
        }

        .brand-logo-img {
            width: 60px !important;
            height: 60px !important;
            max-width: 60px !important;
            background-color: #ffffff;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            object-fit: contain;
        }

        .brand-name {
            font-size: 20px;
            font-weight: 800;
            color: #1e3a70;
        }

        .nav-menu {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .nav-item a, .dropdown-btn {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            padding: 12px 16px;
            color: #274472;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            border-radius: 10px;
            transition: all 0.25s ease;
            background: none;
            border: none;
            cursor: pointer;
        }

        .nav-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .nav-item a:hover, .dropdown-btn:hover {
            background-color: rgba(255, 255, 255, 0.4);
            color: #102a56;
            transform: translateX(4px);
        }

        .nav-item.active > a, .nav-item.active > .dropdown-btn {
            background-color: #ffffff;
            color: #3b62ac;
            font-weight: 700;
            box-shadow: 0 4px 14px rgba(60, 98, 172, 0.18);
        }

        .nav-item i {
            font-size: 16px;
            width: 20px;
            text-align: center;
        }

        .arrow-icon {
            font-size: 12px !important;
            transition: transform 0.3s ease;
        }

        /* --- SUB-MENU DATA MASTER --- */
        .sub-menu {
            list-style: none;
            display: none;
            flex-direction: column;
            gap: 4px;
            padding-left: 32px;
            margin-top: 4px;
        }

        .sub-menu.show {
            display: flex;
        }

        .sub-menu a {
            padding: 8px 12px;
            font-size: 13px;
            color: #274472;
            border-radius: 6px;
            text-decoration: none;
            display: block;
            transition: background 0.2s;
        }

        .sub-menu a:hover {
            background-color: rgba(255, 255, 255, 0.4);
            color: #102a56;
        }

        .logout-btn {
            display: flex;
            align-items: center;
            gap: 12px;
            width: 100%;
            padding: 12px 16px;
            color: #e11d48;
            background: transparent;
            border: none;
            font-weight: 700;
            font-size: 14px;
            border-radius: 10px;
            transition: all 0.2s ease;
            cursor: pointer;
            text-align: left;
            margin-top: 16px;
        }

        .logout-btn:hover {
            background-color: rgba(255, 255, 255, 0.5);
            color: #be123c;
        }

        /* --- MAIN WRAPPER --- */
        .main-wrapper {
            margin-left: var(--sidebar-width);
            flex: 1;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: var(--background) !important;
        }

        /* --- TOPBAR (PASTEL BLUE) --- */
        .topbar {
            height: var(--topbar-height);
            background: var(--gradient-pastel);
            border-bottom: 1px solid rgba(255, 255, 255, 0.4);
            display: flex;
            align-items: center;
            justify-content: flex-end;
            padding: 0 36px;
            gap: 20px;
            position: sticky;
            top: 0;
            z-index: 90;
            box-shadow: 0 4px 15px rgba(123, 159, 232, 0.12);
        }

        .topbar-icon {
            color: #274472;
            font-size: 18px;
            cursor: pointer;
            position: relative;
            padding: 8px;
            border-radius: 50%;
            transition: all 0.2s ease;
        }

        .topbar-icon:hover {
            background-color: rgba(255, 255, 255, 0.4);
            color: #102a56;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            padding: 6px 12px;
            border-radius: 30px;
            transition: background 0.2s;
        }

        .user-profile:hover {
            background-color: rgba(255, 255, 255, 0.3);
        }

        .avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background-color: #ffffff;
            border: 2px solid rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #3b62ac;
            font-size: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .user-name {
            font-size: 14px;
            font-weight: 700;
            color: #1e3a70;
        }

        /* --- MAIN CONTENT --- */
        .content {
            padding: 36px;
            flex: 1;
            background-color: var(--background) !important;
        }

        .page-title {
            font-size: 28px;
            font-weight: 800;
            color: #1e3a70;
            margin-bottom: 28px;
        }

        /* --- STATS GRID --- */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 36px;
        }

        .stat-card {
            background-color: var(--card-bg);
            border: 1px solid rgba(186, 210, 240, 0.6);
            border-radius: var(--radius);
            padding: 24px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(123, 159, 232, 0.12);
        }

        .stat-title {
            font-size: 13px;
            font-weight: 700;
            color: var(--text-muted);
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: var(--text-main);
        }

        .stat-card.total .stat-value { color: #1e3a70; }
        .stat-card.pending .stat-value { color: #64748b; }
        .stat-card.diproses .stat-value { color: #d97706; }
        .stat-card.selesai .stat-value { color: #16a34a; }
        .stat-card.ditolak .stat-value { color: #dc2626; }

        /* --- RECENT REPORTS SECTION --- */
        .section-header {
            font-size: 18px;
            font-weight: 700;
            color: #1e3a70;
            margin-bottom: 16px;
        }

        .report-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .report-card {
            background-color: var(--card-bg);
            border: 1px solid rgba(186, 210, 240, 0.6);
            border-radius: var(--radius);
            padding: 16px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: var(--shadow);
            transition: all 0.2s ease;
        }

        .report-card:hover {
            border-color: #7b9fe8;
            box-shadow: 0 6px 16px rgba(123, 159, 232, 0.1);
        }

        .report-info-group {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .report-thumbnail {
            width: 52px;
            height: 52px;
            background-color: #eaf0ff;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #3b62ac;
            font-size: 20px;
            border: 1px solid rgba(186, 210, 240, 0.6);
        }

        .report-details {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .report-title {
            font-size: 15px;
            font-weight: 700;
            color: #1e3a70;
        }

        .report-date {
            font-size: 12px;
            color: var(--text-muted);
        }

        .report-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .status-badge {
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .badge-diproses { background-color: #fef3c7; color: #b45309; }
        .badge-selesai { background-color: #dcfce7; color: #15803d; }
        .badge-ditolak { background-color: #fee2e2; color: #b91c1c; }

        .btn-dropdown {
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 16px;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            transition: background 0.2s;
        }

        .btn-dropdown:hover {
            background-color: #f1f5f9;
            color: var(--text-main);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
                padding: 16px 8px;
            }
            .brand-name, .nav-item span, .logout-btn span, .arrow-icon, .sub-menu {
                display: none !important;
            }
            .main-wrapper {
                margin-left: 70px;
            }
            .content {
                padding: 20px;
            }
        }
    </style>
    </head>
<body>

    <!-- SIDEBAR NAVIGATION -->
    <aside class="sidebar">
        <div>
            <!-- Logo Brand -->
            <div class="brand">
                <img src="<?php echo e(asset('images/logo BaktiVoice.png')); ?>" alt="Logo BaktiVoice" class="brand-logo-img">
                <span class="brand-name">BaktiVoice</span>
            </div>

            <!-- Navigasi Utama -->
            <ul class="nav-menu">
                <li class="nav-item active">
                    <a href="<?php echo e(route('dashboard_admin')); ?>">
                        <div class="nav-content">
                            <i class="fa-regular fa-file-lines"></i>
                            <span>Laporan</span>
                        </div>
                    </a>
                </li>

                <!-- MENU DATA MASTER (DROPDOWN) -->
                <li class="nav-item">
                    <button class="dropdown-btn" onclick="toggleDropdown('masterMenu', 'masterArrow')">
                        <div class="nav-content">
                            <i class="fa-solid fa-database"></i>
                            <span>Data Master</span>
                        </div>
                        <i class="fa-solid fa-chevron-down arrow-icon" id="masterArrow"></i>
                    </button>
                    <ul class="sub-menu" id="masterMenu">
                        <li><a href="<?php echo e(route('data_master')); ?>">Kategori Laporan</a></li>
                        <li><a href="<?php echo e(route('data_master')); ?>">Status Laporan</a></li>
                        <li><a href="<?php echo e(route('data_master')); ?>">User & Role</a></li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('rekap_laporan')); ?>">
                        <div class="nav-content">
                            <i class="fa-solid fa-chart-column"></i>
                            <span>Rekap Laporan</span>
                        </div>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('notifikasi_admin')); ?>">
                        <div class="nav-content">
                            <i class="fa-regular fa-bell"></i>
                            <span>Notifikasi</span>
                        </div>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('profil_admin')); ?>">
                        <div class="nav-content">
                            <i class="fa-regular fa-user"></i>
                            <span>Profil</span>
                        </div>
                    </a>
                </li>
            </ul>
        </div>

        <!-- Form Logout -->
        <form action="<?php echo e(route('logout')); ?>" method="POST" style="margin-top: 16px;">
            <?php echo csrf_field(); ?>
            <button type="submit" class="logout-btn">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </button>
        </form>
    </aside>

    <!-- MAIN WRAPPER -->
    <div class="main-wrapper">

        <!-- TOPBAR / HEADER -->
        <header class="topbar">
            <div class="topbar-icon" title="Notifikasi">
                <i class="fa-regular fa-bell"></i>
            </div>
            <div class="user-profile">
                <div class="avatar">
                    <i class="fa-regular fa-user"></i>
                </div>
                <span class="user-name"><?php echo e(Auth::user()->name ?? 'Admin Sekolah'); ?></span>
            </div>
        </header>

        <!-- MAIN CONTENT AREA -->
        <main class="content">
            <h1 class="page-title">Dashboard</h1>

            <!-- 5 SUMMARY STATS CARDS (DINAMIS) -->
            <section class="stats-grid">
                <div class="stat-card total">
                    <div class="stat-title">Total</div>
                    <div class="stat-value"><?php echo e($totalLaporan ?? 0); ?></div>
                </div>
                <div class="stat-card pending">
                    <div class="stat-title">Pending</div>
                    <div class="stat-value"><?php echo e($pendingCount ?? 0); ?></div>
                </div>
                <div class="stat-card diproses">
                    <div class="stat-title">Diproses</div>
                    <div class="stat-value"><?php echo e($diprosesCount ?? 0); ?></div>
                </div>
                <div class="stat-card selesai">
                    <div class="stat-title">Selesai</div>
                    <div class="stat-value"><?php echo e($selesaiCount ?? 0); ?></div>
                </div>
                <div class="stat-card ditolak">
                    <div class="stat-title">Ditolak</div>
                    <div class="stat-value"><?php echo e($ditolakCount ?? 0); ?></div>
                </div>
            </section>

            <!-- LAPORAN TERBARU SECTION (DINAMIS) -->
           <section>
    <h2 class="section-header">Laporan Terbaru</h2>

    <div class="report-list">

        <?php $__empty_1 = true; $__currentLoopData = $laporanTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <div class="report-card">

                <div class="report-info-group">

                    <div class="report-thumbnail">
                        <?php if($item->bukti_url): ?>
                            <img
                                src="<?php echo e(asset($item->bukti_url)); ?>"
                                alt="Bukti Laporan"
                                style="width: 100%; height: 100%; object-fit: cover; border-radius: 10px;"
                            >
                        <?php else: ?>
                            <i class="fa-regular fa-image"></i>
                        <?php endif; ?>
                    </div>

                    <div class="report-details">
                        <div class="report-title">
                            <?php echo e($item->judul_laporan); ?>

                        </div>

                        <div class="report-date">
                            <?php echo e($item->created_at->format('d M Y')); ?>

                        </div>
                    </div>

                </div>

                <div class="report-actions">

                    <?php
                        $namaStatus = strtolower($item->status ?? 'pending');
                    ?>

                    <span class="status-badge badge-<?php echo e($namaStatus); ?>">
                        <?php echo e(ucfirst($namaStatus)); ?>

                    </span>

                    <a
                        href="<?php echo e(route('laporan.show', $item->id_laporan)); ?>"
                        class="btn-dropdown"
                        title="Detail"
                    >
                        <i class="fa-solid fa-chevron-right"></i>
                    </a>

                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="empty-state">
                <i class="fa-regular fa-folder-open"
                   style="font-size: 32px; margin-bottom: 8px;"></i>
                <p>Belum ada laporan terbaru.</p>
            </div>

        <?php endif; ?>

    </div>
            </section>
        </main>
    </div>

    <!-- SCRIPT DROPDOWN TOGGLE -->
    <script>
        function toggleDropdown(menuId, arrowId) {
            const menu = document.getElementById(menuId);
            const arrow = document.getElementById(arrowId);

            menu.classList.toggle('show');

            if (menu.classList.contains('show')) {
                arrow.style.transform = 'rotate(180deg)';
            } else {
                arrow.style.transform = 'rotate(0deg)';
            }
        }
    </script>
</body>
</html>
<?php /**PATH D:\BaktiVoice\BaktiVoice\resources\views/dashboard_admin.blade.php ENDPATH**/ ?>