<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\BaktiVoice\BaktiVoice\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>