<?php echo e($slot); ?>

<?php /**PATH D:\BaktiVoice\BaktiVoice\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>